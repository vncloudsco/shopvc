<?php

if ( isset($_SESSION['flash']) ) {
	unset($_SESSION['flash']);
}