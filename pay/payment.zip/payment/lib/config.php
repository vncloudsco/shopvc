<?php

$config = array(

	/*
	* ADMIN ACCESS CREDENTIALS
	*/
	'admin_username' => 'admin', // username used to login to the admin area
	'admin_password' => 'admin', // password used to login to the admin area

	/*
	* DATABASE ACCESS CREDENTIALS
	*/
	'db_host' => 'localhost', // database host, usually localhost
	'db_username' => '', // database username
	'db_password' => '', // datebase password
	'db_name' => '', // database name

);