<?php

class Payment extends Model {
	public static $_table = 'payments';

}