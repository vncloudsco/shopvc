<?php

class Config extends Model {
	public static $_table = 'config';

}