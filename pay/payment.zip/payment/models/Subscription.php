<?php

class Subscription extends Model {
	public static $_table = 'subscriptions';

}