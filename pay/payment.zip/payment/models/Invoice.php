<?php

class Invoice extends Model {
	public static $_table = 'invoices';

}