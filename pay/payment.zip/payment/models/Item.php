<?php

class Item extends Model {
	public static $_table = 'items';

}